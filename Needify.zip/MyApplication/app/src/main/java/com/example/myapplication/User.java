package com.example.myapplication;

public class User {

    String name,phone,details,address;

    public String getName() {
        return name;
    }

    public String getPhone() {
        return phone;
    }

    public String getDetails() {
        return details;
    }

    public String getAddress() {
        return address;
    }
}
