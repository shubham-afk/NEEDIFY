package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class sendelec extends AppCompatActivity {

    EditText mname,maddress,mphone,mdetails;
    Button reg,sendto;

    DatabaseReference reff;
    Info info;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sendelec);

        mname = findViewById(R.id.textname);
        maddress = findViewById(R.id.textadd);
        mphone = findViewById(R.id.textphone);
        mdetails = findViewById(R.id.textdet);
        reg = findViewById(R.id.buttonelec);
        sendto = findViewById(R.id.send);
        info = new Info();
        reff = FirebaseDatabase.getInstance().getReference().child("Info");

        reg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                info.setName(mname.getText().toString().trim());
                info.setAddress(maddress.getText().toString().trim());
                info.setPhone(mphone.getText().toString().trim());
                info.setDetails(mdetails.getText().toString().trim());
                reff.push().setValue(info);
                Toast.makeText(sendelec.this,"data inserted",Toast.LENGTH_LONG).show();

            }
        });
        sendto.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(),userlist.class));
            }
        });
    }
}